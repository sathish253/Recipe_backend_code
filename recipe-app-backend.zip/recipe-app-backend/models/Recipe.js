const mongoose = require('mongoose'); 
const recipeSchema = new mongoose.Schema({
    title: String,
    ingredients: [{ name: String, quantity: String }],
    instructions: [String],
    tags: [String],
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    createdAt: { type: Date, default: Date.now },
  });
  recipeSchema.index({ title: "text", tags: 1 });
  module.exports = mongoose.model("Recipe", recipeSchema);
  