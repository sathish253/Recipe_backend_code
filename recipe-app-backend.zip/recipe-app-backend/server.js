const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const app = express();

require("dotenv").config();

app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI);

// Models
const User = require("./models/User");
const Recipe = require("./models/Recipe");
const Favorite = require("./models/Favorite");

// Middleware for authentication
const authMiddleware = async (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Unauthorized" });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ message: "Invalid token" });
  }
};

// Auth routes
app.post("/api/auth/register", async (req, res) => {
  const { email, password } = req.body;
  const passwordHash = await bcrypt.hash(password, 10);
  try {
    const user = await User.create({ email, passwordHash });
    res.status(201).json({ message: "User created" });
  } catch (err) {
    res.status(400).json({ message: "User already exists" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ message: "Invalid credentials" });
  }
  const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET);
  res.json({ token });
});

// Recipe routes
app.post("/api/recipes", authMiddleware, async (req, res) => {
  const recipe = await Recipe.create({
    ...req.body,
    createdBy: req.user.id,
    createdAt: new Date(),
  });
  res.status(201).json(recipe);
});

app.get("/api/recipes", async (req, res) => {
  const { search, tag } = req.query;
  const query = {};
  if (search) query.title = { $regex: search, $options: "i" };
  if (tag) query.tags = tag;
  const recipes = await Recipe.find(query);
  res.json(recipes);
});

app.get("/api/recipes/:recipeId", async (req, res) => {
  const recipe = await Recipe.findById(req.params.recipeId);
  res.json(recipe);
});

app.put("/api/recipes/:recipeId", authMiddleware, async (req, res) => {
  const recipe = await Recipe.findOneAndUpdate(
    { _id: req.params.recipeId, createdBy: req.user.id },
    req.body,
    { new: true }
  );
  res.json(recipe);
});

app.delete("/api/recipes/:recipeId", authMiddleware, async (req, res) => {
  await Recipe.deleteOne({ _id: req.params.recipeId, createdBy: req.user.id });
  res.json({ message: "Deleted" });
});

// Favorite routes
app.post("/api/recipes/:recipeId/favorite", authMiddleware, async (req, res) => {
  await Favorite.updateOne(
    { userId: req.user.id, recipeId: req.params.recipeId },
    {},
    { upsert: true }
  );
  res.json({ message: "Recipe favorited" });
});

app.delete("/api/recipes/:recipeId/favorite", authMiddleware, async (req, res) => {
  await Favorite.deleteOne({ userId: req.user.id, recipeId: req.params.recipeId });
  res.json({ message: "Removed from favorites" });
});

app.get("/api/users/:userId/favorites", authMiddleware, async (req, res) => {
  const favorites = await Favorite.find({ userId: req.params.userId }).populate("recipeId");
  res.json(favorites.map(f => f.recipeId));
});

app.listen(5000, () => console.log("Server running on port 5000"));
